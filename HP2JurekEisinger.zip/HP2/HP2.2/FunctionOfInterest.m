% simple file containing the function of interest 

function y = FunctionOfInterest(x1, x2)
    y = (x1^2 + x2 - 11)^2 + (x1+x2^2-7)^2;
end